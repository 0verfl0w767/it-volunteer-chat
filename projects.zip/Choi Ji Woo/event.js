

const nutchao = document.getElementById('btn-hi');
nutchao.addEventListener('click', function() {
    confetti({
        particleCount: 2000, 
        spread: 360,         
        origin: { y: 0.8 }  
    });
    setTimeout(function() {
        alert('Welcome to my profile!!! ✨🎉');
    });

});

const nutDark = document.getElementById('btn-dark-mode');
let dangMoToi = false;

nutDark.addEventListener('click', function() {
    const tatCaTieuDe = document.querySelectorAll('.section-title, .name, h1, h2, strong');
    const tatCaDoanVan = document.querySelectorAll('p, li, .skill-item');
    const khungNoiDungDuoi = document.querySelector('.content-box');

    if (dangMoToi === false) {
        
        document.body.style.backgroundImage = "url('backdark.avif')";
        document.body.style.backgroundColor = '#121212'; 
        document.querySelector('.container').style.backgroundColor = '#1e1e1e'; 
        
        if (khungNoiDungDuoi) {
            khungNoiDungDuoi.style.backgroundColor = '#2a2a2a';
            khungNoiDungDuoi.style.borderColor = '#444444';
        }

        tatCaTieuDe.forEach(el => el.style.color = '#ffffff');
        tatCaDoanVan.forEach(el => el.style.color = '#e0e0e0');

        nutDark.innerText = '☀️ Lightmode';
        dangMoToi = true;
    } else {

        document.body.style.backgroundImage = "url('back.jpg')";
        document.body.style.backgroundColor = '#f4f7f6';
        document.querySelector('.container').style.backgroundColor = '#ffffff';
        
        if (khungNoiDungDuoi) {
            khungNoiDungDuoi.style.backgroundColor = '#fafbfc';
            khungNoiDungDuoi.style.borderColor = '#e1e8ed';
        }

        tatCaTieuDe.forEach(el => el.style.color = '#2c3e50');
        tatCaDoanVan.forEach(el => el.style.color = '#333333');

        nutDark.innerText = '🌙 Darkmode ';
        dangMoToi = false;
    }
});

const anhAvatar = document.querySelector('.avatar');
    
    anhAvatar.addEventListener('mouseover', function() {
        anhAvatar.style.transform = 'scale(1.1)'; 
        anhAvatar.style.transition = 'all 0.3s ease'; 
        anhAvatar.style.borderColor = '#ff5722';
    });

    anhAvatar.addEventListener('mouseleave', function() {
        anhAvatar.style.transform = 'scale(1)'; 
        anhAvatar.style.borderColor = '#007bff';
    });
